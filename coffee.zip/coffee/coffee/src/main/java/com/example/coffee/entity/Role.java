package com.example.coffee.entity;

public enum  Role {
    ADMIN,
    TECHNICIAN
}
