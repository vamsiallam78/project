package com.example.coffee.dto;
import com.example.coffee.entity.Role;
import lombok.*;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RegisterRequest {
    private String email;
    private String password;
    private String name;
    private Role role;
   
}